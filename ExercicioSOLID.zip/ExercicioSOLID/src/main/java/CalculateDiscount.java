public interface CalculateDiscount {

    double calcular();

}

public class EmailService {

    public void sendEmailConfirmation(String email) {
        System.out.println("Enviando email de confirmação para: " + email);
    }

}

import java.util.List;

public class OrderRepository {

    public void saveToDatabase(List<String> orders) {
        System.out.println("Salvando pedidos no banco de dados...");
    }

}
public class ClienteVip implements CalculateDiscount {
    double total;
    @Override
    public double calcular() {
        return 0.2;
    }
}

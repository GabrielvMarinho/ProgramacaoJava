public class ExceptionBarcoCheio extends ExceptionTravessiaJogo{
    public ExceptionBarcoCheio(){ super("O barco esta CHEIO!");
    }
}

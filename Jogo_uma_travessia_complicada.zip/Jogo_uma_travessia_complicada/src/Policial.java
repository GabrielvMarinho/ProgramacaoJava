public class Policial extends Adulto{
    public Policial(int id, String icon){
        super(id, icon);
    }
}

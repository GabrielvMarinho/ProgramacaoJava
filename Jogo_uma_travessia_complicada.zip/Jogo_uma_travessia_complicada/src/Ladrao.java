public class Ladrao extends Pessoa{
    public Ladrao(int id, String icon){
        super(id, icon);
    }
}

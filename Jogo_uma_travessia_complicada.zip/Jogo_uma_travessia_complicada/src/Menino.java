public class Menino extends Pessoa{
    public Menino(int id, String icon){
        super(id, icon);
    }
}

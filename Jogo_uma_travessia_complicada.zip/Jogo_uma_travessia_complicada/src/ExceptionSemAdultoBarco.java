public class ExceptionSemAdultoBarco extends ExceptionTravessiaJogo{
    public ExceptionSemAdultoBarco(){
        super("O barco não possui ADULTOS!");
    }

}

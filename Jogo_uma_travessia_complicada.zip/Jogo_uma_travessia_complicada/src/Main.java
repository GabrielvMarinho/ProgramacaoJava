import java.io.OutputStream;
import java.sql.SQLOutput;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    static Scanner sc = new Scanner(System.in);
    static Barco barco;
    public static void main(String[] args) throws Exception {

        setarObjetos();
        mostrarIntrucoes();
        try {
            do {
                try {
                    //mostrando o status do jogo (posição do barco, pessoas, etc.)
                    GerenT.retornarStatus(barco);
                    //pegando o id que vai sofrer a ação
                    int id = pegarId();

                    if (id == 0) {
                        //validação para a troca de margem
                        GerenT.validacaoDeTrocaDeMargem(barco.getMargemProxima(), barco.getMargemDistante(), barco);
                        //trocar de fato após validação
                        barco.mudarLado();
                    } else {
                        Pessoa escolhido = GerenT.returnById(id);
                        //valida para ver se ele esta em um barco ou borda para mudar a logica
                        if (GerenT.emQualMargemEsta(escolhido) == null) {
                            //pega a borda mais proxima do barco baseado em um atributo
                            GerenT.moverDePara(escolhido, barco, barco.getMargemProxima());
                        } else {
                            GerenT.moverDePara(escolhido, GerenT.emQualMargemEsta(escolhido), barco);
                        }
                    }
                    if (GerenT.checarVitoria()) {
                        //desenho no terminal da vitória
                        mensagemVenceu();
                        break;
                    }

                } catch (ExceptionTravessiaJogo e) {
                    System.out.println("▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇");
                    System.out.println("  " + e.getMessage());
                    System.out.println("▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇");
                }
            } while (true);

        }catch(Exception e){
            System.err.println("ERRO FATAL: "+e.getMessage());
        }
        }

    //mostrar mensagem de vítória final do jogo
    public static void mensagemVenceu(){
        System.out.println("\uD83C\uDF89\uD83C\uDF89\uD83C\uDF89\uD83C\uDF89\uD83C\uDF89\uD83C\uDF89\uD83C\uDF89\uD83C\uDF89\uD83C\uDF89");
        System.out.println("\uD83C\uDF89\uD83C\uDF89 PARABÉNS \uD83C\uDF89\uD83C\uDF89\uD83C\uDF89");
        System.out.println("\uD83C\uDF89\uD83C\uDF89\uD83C\uDF89\uD83C\uDF89\uD83C\uDF89\uD83C\uDF89\uD83C\uDF89\uD83C\uDF89\uD83C\uDF89");
        System.out.println("Você concluiu o jogo com SUCESSO!");
    }
    //mostrar instruções início do jogo
    public static void mostrarIntrucoes(){
        System.out.println("---------------------------------");
        System.out.println("REGRAS DO JOGO");
        System.out.println("I) A jangada só pode carregar duas pessoas por vez.\n" +
                "II) Somente o pai, a mãe e o policial sabem manobrar a jangada.\n" +
                "III) Os filhos não podem ficar com a mãe na ausência do pai, em nenhuma das duas margens do rio.\n" +
                "IV) Os filhos não podem ser transportados pela mãe.\n" +
                "V) As filhas não podem ficar com o pai na ausência da mãe, em nenhuma das duas margens do rio.\n" +
                "VI) As filhas não podem ser transportadas pelo pai.\n" +
                "VII) O ladrão não pode ficar com membros da família na ausência do policial, mas ela pode ficar isolada em qualquer margem do rio.");
        System.out.println("\nPAI -> \uD83D\uDE4D\u200D♂\uFE0F"+
                "\nFILHOS -> \uD83D\uDC66"+
                "\nMÃE -> \uD83D\uDE4D\u200D♀\uFE0F"+
                "\nFILHAS -> \uD83D\uDC67"+
                "\nPOLICIAL -> \uD83D\uDC6E\uD83C\uDFFB"+
                "\nLADRÃO -> \uD83D\uDE08");

        System.out.println("Digite qualquer caracter para iniciar\n");
        sc.next();
    }
    //criação de objetos início do jogo
    public static void setarObjetos(){
        Pessoa pessoa1 = new Policial(1, "\uD83D\uDC6E\uD83C\uDFFB");
        Pessoa pessoa2 = new Ladrao(2, "\uD83D\uDE08");
        Pessoa pessoa3 = new Homem(3, "\uD83D\uDE4D\u200D♂\uFE0F");
        Pessoa pessoa4 = new Menino(4, "\uD83D\uDC66");
        Pessoa pessoa5 = new Menino(5, "\uD83D\uDC66");
        Pessoa pessoa6 = new Mulher(6, "\uD83D\uDE4D\u200D♀\uFE0F");
        Pessoa pessoa7 = new Menina(7, "\uD83D\uDC67");
        Pessoa pessoa8 = new Menina(8, "\uD83D\uDC67");
        barco = new Barco();

    }
    //pegar id do personagem
    public static int pegarId(){
        System.out.println("digite o id");
        int id = sc.nextInt();
        System.out.println("\n\n\n\n\n\n\n\n\n\n");
        return id;
    }
}
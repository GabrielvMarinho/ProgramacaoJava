public class Homem extends Adulto{
    public Homem(int id, String icon){
        super(id, icon);
    }
}

public class Mulher extends Adulto{
    public Mulher(int id, String icon){
        super(id, icon);
    }
}

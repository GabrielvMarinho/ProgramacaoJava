public class Adulto extends Pessoa{

    public Adulto(int id, String icon){
        super(id, icon);
    }
}

public class Menina extends Pessoa{
    public Menina(int id, String icon){
        super(id, icon);
    }
}

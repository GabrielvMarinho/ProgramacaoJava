public class ExceptionIdNaoExiste extends ExceptionTravessiaJogo{
    public ExceptionIdNaoExiste(){
        super("O id NÃO EXISTE!");
    }

}

public class ExceptionPaiBateuMenina extends ExceptionTravessiaJogo{
    ExceptionPaiBateuMenina(){
        super("O pai BATEU na MENINA!");
    }
}

public class ExceptionMaeBateuMenino extends ExceptionTravessiaJogo{
    ExceptionMaeBateuMenino(){
        super("A mae BATEU no MENINO!");
    }
}

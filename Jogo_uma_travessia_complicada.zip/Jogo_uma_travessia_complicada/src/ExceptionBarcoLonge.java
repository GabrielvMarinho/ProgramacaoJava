public class ExceptionBarcoLonge extends ExceptionTravessiaJogo{
    public ExceptionBarcoLonge(){
        super("O barco está MUITO LONGE!");
    }


}

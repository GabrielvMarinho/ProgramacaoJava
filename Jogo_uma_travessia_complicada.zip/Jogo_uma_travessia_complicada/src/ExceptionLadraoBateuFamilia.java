public class ExceptionLadraoBateuFamilia extends ExceptionTravessiaJogo{
    ExceptionLadraoBateuFamilia(){
        super("o ladrao BATEU na FAMÍLIA!");
    }
}

public class ExceptionTravessiaJogo extends Exception{
    public ExceptionTravessiaJogo(String s){
        super("Erro: "+s);
    }
}

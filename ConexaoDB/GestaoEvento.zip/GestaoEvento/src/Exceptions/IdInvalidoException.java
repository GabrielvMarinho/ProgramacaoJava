package Exceptions;



public class IdInvalidoException extends Exception{
    public IdInvalidoException(){
        super("Id não encontrado!");
    }
}
